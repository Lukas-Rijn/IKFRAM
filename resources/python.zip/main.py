import sqlite3
import json
import tarfile
import sys
import threading

def extractDBfromTar(image):
    tar = tarfile.open(image)
    print("Extracting database")
    tar.extract("data/data/com.whatsapp/databases/msgstore.db")
    print("Finished!")

def getAllMessages(path):
    conn = sqlite3.connect(path)
    conn.row_factory = sqlite3.Row # This enables column access by name: row['column_name']
    db = conn.cursor()

    rows = db.execute('''
    SELECT * from message
    ''').fetchall()

    conn.commit()
    conn.close()

    return json.dumps([dict(ix) for ix in rows])

def getIdJidPairs(path):
    conn = sqlite3.connect(path)
    conn.row_factory = sqlite3.Row
    db = conn.cursor()

    allJids = db.execute('''
        SELECT raw_string_jid from chat
        ''').fetchall()
    allIDs = db.execute('''
        SELECT _id from chat
        ''').fetchall()
    conn.commit()
    conn.close()

    idjidPairs = []
    for i in range(len(allJids)):
        idjidPairs.append([allIDs[i], allJids[i]])

    return idjidPairs

def identifyMessageSender(idJidPairs, messagesJSON):
    for x in messagesJSON:
        for y in idJidPairs:
            if x["chat_row_id"] == y[0]:
                print("wow")



if __name__ == "__main__":
    whatsappDatabasePath = "data\\data\\com.whatsapp\\databases\\msgstore.db"
    #Extract the database from the image with the given CLI argument
    #image = sys.argv[0]
    extractDBfromTar("C:\\Users\\luuk9\\Desktop\\test.tar")

    #Get all messages
    messagesJSON = getAllMessages(whatsappDatabasePath)
    #Get id and jid pairs
    idjidpairs = getIdJidPairs(whatsappDatabasePath)


